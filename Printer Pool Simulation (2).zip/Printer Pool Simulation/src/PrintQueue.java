import java.util.*;
import java.util.concurrent.*;
import java.io.*;

class PrintQueue {
    private PrintJob[] buffer;
    private int head = 0;
    private int tail = 0;
    private int capacity;

    private Semaphore mutex;
    private Semaphore empty;
    private Semaphore full;

    public PrintQueue(int capacity) {
        this.capacity = capacity;
        this.buffer = new PrintJob[capacity];
        this.mutex = new Semaphore(1);
        this.empty = new Semaphore(capacity);
        this.full = new Semaphore(0);
    }


    public boolean addJob(PrintJob job) {
        try {

            if (!empty.tryAcquire()) {
                return false;
            }

            mutex.acquire();


            buffer[tail] = job;
            job.queuedTime = System.currentTimeMillis();
            tail = (tail + 1) % capacity;

            mutex.release();
            full.release();

            return true;

        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return false;
        }
    }


    public PrintJob takeJob() throws InterruptedException {
        full.acquire();
        mutex.acquire();


        PrintJob job = buffer[head];
        buffer[head] = null;
        head = (head + 1) % capacity;

        mutex.release();
        empty.release();

        return job;
    }

    public int getSize() {
        return full.availablePermits();
    }
}