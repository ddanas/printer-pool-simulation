import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

class EventLogger {
    private PrintWriter writer;
    private long startTime;

    public EventLogger(String filename) throws IOException {
        this.writer = new PrintWriter(new FileWriter(filename));
        this.startTime = System.currentTimeMillis();
        writer.println("Time(ms),Event,Details");
    }

    public synchronized void log(String event, String details) {
        long elapsed = System.currentTimeMillis() - startTime;
        writer.println(elapsed + "," + event + "," + details);
        writer.flush();
    }

    public void close() {
        writer.close();
    }
}