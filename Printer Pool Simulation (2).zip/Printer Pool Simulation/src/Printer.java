import java.util.Random;

class Printer extends Thread {
    private int printerId;
    private PrintQueue queue;
    private EventLogger logger;
    private Statistics stats;
    private Random random;
    private int minPrintTime;
    private int maxPrintTime;
    private boolean running = true;

    public Printer(int id, PrintQueue queue, EventLogger logger, Statistics stats,
                   int minPrintTime, int maxPrintTime, long seed) {
        this.printerId = id;
        this.queue = queue;
        this.logger = logger;
        this.stats = stats;
        this.minPrintTime = minPrintTime;
        this.maxPrintTime = maxPrintTime;
        this.random = new Random(seed + 1000 + id);
        setName("Printer-" + id);
    }

    public void run() {
        while (running) {
            try {
                logger.log("PRINTER_SLEEPING", "PrinterId=" + printerId);

                // Take job from queue (SLEEPS if empty - waits on full semaphore)
                PrintJob job = queue.takeJob();

                job.startPrintTime = System.currentTimeMillis();
                logger.log("PRINTER_WAKEUP", "PrinterId=" + printerId + ",JobId=" + job.jobId);
                logger.log("PRINTER_STARTED", "PrinterId=" + printerId + ",JobId=" + job.jobId + ",Student=" + job.studentId);

                // Simulate printing
                int printTime = minPrintTime + random.nextInt(maxPrintTime - minPrintTime + 1);
                Thread.sleep(printTime);

                job.completionTime = System.currentTimeMillis();
                stats.jobCompleted(job);

                long waitTime = job.startPrintTime - job.queuedTime;
                logger.log("PRINTER_FINISHED", "PrinterId=" + printerId + ",JobId=" + job.jobId + ",WaitTime=" + waitTime + "ms");

            } catch (InterruptedException e) {
                break;
            }
        }
        logger.log("PRINTER_EXIT", "PrinterId=" + printerId);
    }

    public void shutdown() {
        running = false;
        interrupt();
    }
}