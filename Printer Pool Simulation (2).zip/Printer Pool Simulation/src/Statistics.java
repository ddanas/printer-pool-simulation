class Statistics {
    private int jobsSubmitted = 0;
    private int jobsDropped = 0;
    private int jobsCompleted = 0;
    private long totalWaitTime = 0;

    public synchronized void jobSubmitted() {
        jobsSubmitted++;
    }

    public synchronized void jobDropped() {
        jobsDropped++;
    }

    public synchronized void jobCompleted(PrintJob job) {
        jobsCompleted++;
        totalWaitTime += (job.startPrintTime - job.queuedTime);
    }

    public synchronized void printReport() {
        System.out.println("\n=== STATISTICS ===");
        System.out.println("Jobs Submitted: " + jobsSubmitted);
        System.out.println("Jobs Completed: " + jobsCompleted);
        System.out.println("Jobs Dropped: " + jobsDropped);
        if (jobsSubmitted + jobsDropped > 0) {
            double dropRate = (jobsDropped * 100.0) / (jobsSubmitted + jobsDropped);
            System.out.println("Drop Rate: " + String.format("%.2f%%", dropRate));
        }
        if (jobsCompleted > 0) {
            double avgWait = totalWaitTime / (double)jobsCompleted;
            System.out.println("Average Wait Time: " + String.format("%.2f ms", avgWait));
            System.out.println("Throughput: " + String.format("%.2f jobs/sec", jobsCompleted / 30.0));
        }
    }
}
