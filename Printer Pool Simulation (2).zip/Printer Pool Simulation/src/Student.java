import java.util.Random;

class Student extends Thread {
    private int studentId;
    private PrintQueue queue;
    private EventLogger logger;
    private Statistics stats;
    private Random random;
    private int minPrepTime;
    private int maxPrepTime;
    private boolean running = true;
    private int jobCounter = 0;

    public Student(int id, PrintQueue queue, EventLogger logger, Statistics stats,
                   int minPrepTime, int maxPrepTime, long seed) {
        this.studentId = id;
        this.queue = queue;
        this.logger = logger;
        this.stats = stats;
        this.minPrepTime = minPrepTime;
        this.maxPrepTime = maxPrepTime;
        this.random = new Random(seed + id);
        setName("Student-" + id);
    }

    public void run() {
        while (running) {
            try {
                // Prepare print job (random time)
                int prepTime = minPrepTime + random.nextInt(maxPrepTime - minPrepTime + 1);
                Thread.sleep(prepTime);

                // Create job
                PrintJob job = new PrintJob(studentId * 1000 + jobCounter++, studentId);
                logger.log("JOB_CREATED", "Student=" + studentId + ",JobId=" + job.jobId);

                // Try to add to queue (wait on empty semaphore)
                if (queue.addJob(job)) {
                    stats.jobSubmitted();
                    logger.log("JOB_QUEUED", "Student=" + studentId + ",JobId=" + job.jobId);
                } else {
                    // Queue full - job dropped, retry later
                    stats.jobDropped();
                    logger.log("JOB_DROPPED", "Student=" + studentId + ",JobId=" + job.jobId + ",Reason=QueueFull");
                    Thread.sleep(100); // Wait before retry
                }

            } catch (InterruptedException e) {
                break;
            }
        }
        logger.log("STUDENT_EXIT", "Student=" + studentId);
    }

    public void shutdown() {
        running = false;
        interrupt();
    }
}