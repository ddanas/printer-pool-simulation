import java.util.ArrayList;
import java.util.List;

public class PrinterPoolSimulation {

    public static void main(String[] args) {
        System.out.println("=== PRINTER POOL SIMULATION ===");
        System.out.println("Based on Producer-Consumer Problem (Chapter 6)\n");

        // Scenario 1: Light Load
        System.out.println("\n" + "=".repeat(60));
        runScenario("Light_Load", 5, 2, 4, 1000, 3000, 500, 2000, 42, 30000);

        // Scenario 2: High Load
        System.out.println("\n" + "=".repeat(60));
        runScenario("High_Load", 30, 2, 5, 100, 500, 200, 800, 43, 30000);

        // Scenario 3: Burst Arrivals
        System.out.println("\n" + "=".repeat(60));
        runScenario("Burst_Arrivals", 20, 3, 6, 200, 1000, 300, 1200, 44, 30000);

        System.out.println("\n" + "=".repeat(60));
        System.out.println("Simulation complete! Check .log files for event traces.");
    }

    private static void runScenario(String name, int numStudents, int numPrinters,
                                    int queueSize, int minPrepTime, int maxPrepTime,
                                    int minPrintTime, int maxPrintTime, long seed, int duration) {
        System.out.println("\nScenario: " + name);
        System.out.println("Configuration: N=" + numStudents + " students, P=" + numPrinters +
                " printers, Q=" + queueSize + " queue slots");
        System.out.println("Running for " + (duration/1000) + " seconds...");

        try {
            PrintQueue queue = new PrintQueue(queueSize);
            EventLogger logger = new EventLogger(name + ".log");
            Statistics stats = new Statistics();

            logger.log("SIMULATION_START", "Students=" + numStudents + ",Printers=" + numPrinters + ",QueueSize=" + queueSize);

            List<Student> students = new ArrayList<>();
            List<Printer> printers = new ArrayList<>();

            // Start printers first (consumers ready to consume)
            for (int i = 0; i < numPrinters; i++) {
                Printer p = new Printer(i, queue, logger, stats, minPrintTime, maxPrintTime, seed);
                printers.add(p);
                p.start();
            }

            // Start students (producers)
            for (int i = 0; i < numStudents; i++) {
                Student s = new Student(i, queue, logger, stats, minPrepTime, maxPrepTime, seed);
                students.add(s);
                s.start();
            }

            // Run simulation
            Thread.sleep(duration);

            // Shutdown
            logger.log("SIMULATION_STOP", "Duration=" + duration + "ms");

            for (Student s : students) {
                s.shutdown();
            }
            for (Printer p : printers) {
                p.shutdown();
            }

            // Wait for threads to finish
            for (Student s : students) {
                s.join(1000);
            }
            for (Printer p : printers) {
                p.join(1000);
            }

            logger.close();
            stats.printReport();

        } catch (Exception e) {
            System.err.println("Error in scenario " + name + ": " + e.getMessage());
            e.printStackTrace();
        }
    }
}