


class PrintJob {
    int jobId;
    int studentId;
    long createdTime;
    long queuedTime;
    long startPrintTime;
    long completionTime;

    public PrintJob(int jobId, int studentId) {
        this.jobId = jobId;
        this.studentId = studentId;
        this.createdTime = System.currentTimeMillis();
    }
}